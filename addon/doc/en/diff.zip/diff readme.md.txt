readme.md
This readme.md file should not be translated.
It is only used for the githube repository.
Diff between version 3.7 (<) and version 3.8 (>):
9,10c9,10
< 	* Minimum required NVDA version: 2024.1
< 	* Last NVDA version tested: 2025.1
---
> 	* Minimum required NVDA version: 2025.1
> 	* Last NVDA version tested: 2026.1
34c34
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/wordAccessEnhancement/wordAccessEnhancement-3.7.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/wordAccessEnhancement/wordAccessEnhancement-3.8.nvda-addon
