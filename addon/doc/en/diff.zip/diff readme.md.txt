readme.md
This readme.md file should not be translated.
It is only used for the githube repository.
Diff between version 3.8 (<) and version 3.9 (>):
34c34
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/wordAccessEnhancement/wordAccessEnhancement-3.8.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/wordAccessEnhancement/wordAccessEnhancement-3.9.nvda-addon
