Diff between version 3.3.4 (<) and version 3.4 (>):
This readme.md file should not be translated.
It is only used for the githube repository.

10c10
< 	* Last NVDA version tested: 2022.2
---
> 	* Last NVDA version tested: 2023.1
34c34
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/wordAccessEnhancement/wordAccessEnhancement-3.3.4.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/wordAccessEnhancement/wordAccessEnhancement-3.4.nvda-addon
