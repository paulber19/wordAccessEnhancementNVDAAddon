readme.md
This readme.md file should not be translated.
It is only used for the githube repository.
Diff between version 3.5 (<) and version 3.6 (>):
10c10
< 	* Last NVDA version tested: 2024.1
---
> 	* Last NVDA version tested: 2024.4
34c34
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/wordAccessEnhancement/wordAccessEnhancement-3.5.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/wordAccessEnhancement/wordAccessEnhancement-3.6.nvda-addon
